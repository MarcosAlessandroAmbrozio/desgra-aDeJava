package br.edu.ifsc.chapeco.mvc.poe.ui.menu;

import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import br.edu.ifsc.chapeco.mvc.poe.R;
import br.edu.ifsc.chapeco.mvc.poe.databinding.FragmentItemMenuBinding;


import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link MenuItem}.
 * TODO: Replace the implementation with code for your data type.
 */
public class ItemMenuRecyclerViewAdapter extends RecyclerView.Adapter<ItemMenuRecyclerViewAdapter.ViewHolder> {

    private final List<MenuItem> mValues;

    public ItemMenuRecyclerViewAdapter(List<MenuItem> items) {
        mValues = items;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        return new ViewHolder(FragmentItemMenuBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false));

    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem = mValues.get(position);
        holder.mIdView.setText(String.valueOf(mValues.get(position).getId()));
        holder.mContentView.setText(mValues.get(position).getDescricao());
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public final TextView mIdView;
        public final TextView mContentView;
        public MenuItem mItem;

        public ViewHolder(FragmentItemMenuBinding binding) {
            super(binding.getRoot());
            mIdView = binding.itemNumber;
            mContentView = binding.content;

            binding.getRoot().setOnClickListener(this);

        }

        @Override
        public String toString() {
            return super.toString() + " '" + mContentView.getText() + "'";
        }

        @Override
        public void onClick(View view) {
            //CLICK - pegar posicao que foi clicada
            int adapterposition = this.getLayoutPosition();
            // mostrar mensagem
            Snackbar mensagem = Snackbar.make(view,"Menu = " + adapterposition, Snackbar.LENGTH_LONG);
            mensagem.show();
            switch (adapterposition) {
                case 0:
                    Navigation.findNavController(view).navigate(R.id.navigation_login);
                    break;
                case 1:
                    break;
            }


        }
    }
}